# -*- coding: utf-8 -*-

"""
cookiecutter
------------

Main package for Cookiecutter.
"""

__version__ = '1.6.0'
